import tkinter as tk
from tkinter import ttk, messagebox
import openpyxl

class BTreeNodeKV:
    def __init__(self, t, leaf=False):
        self.t = t
        self.leaf = leaf
        self.keys = []
        self.values = []
        self.children = []

class BTreeKV:
    def __init__(self, t):
        self.t = t
        self.root = BTreeNodeKV(t, True)

    def search(self, node, key):
        i = 0
        while i < len(node.keys) and key > node.keys[i]:
            i += 1
        if i < len(node.keys) and key == node.keys[i]:
            return (node, i)
        if node.leaf:
            return None
        return self.search(node.children[i], key)

    def insert(self, key, record):
        found = self.search(self.root, key)
        if found:
            node, idx = found
            node.values[idx].append(record)
        else:
            root = self.root
            if len(root.keys) == (2 * self.t) - 1:
                new_root = BTreeNodeKV(self.t, False)
                new_root.children.append(root)
                self.split_child(new_root, 0)
                self.root = new_root
                self.insert_non_full(new_root, key, record)
            else:
                self.insert_non_full(root, key, record)

    def insert_non_full(self, node, key, record):
        i = len(node.keys) - 1
        if node.leaf:
            node.keys.append(None)
            node.values.append(None)
            while i >= 0 and key < node.keys[i]:
                node.keys[i + 1] = node.keys[i]
                node.values[i + 1] = node.values[i]
                i -= 1
            node.keys[i + 1] = key
            node.values[i + 1] = [record]
        else:
            while i >= 0 and key < node.keys[i]:
                i -= 1
            i += 1
            if len(node.children[i].keys) == (2 * self.t) - 1:
                self.split_child(node, i)
                if key > node.keys[i]:
                    i += 1
            self.insert_non_full(node.children[i], key, record)

    def split_child(self, parent, i):
        t = self.t
        node = parent.children[i]
        new_node = BTreeNodeKV(t, node.leaf)
        parent.children.insert(i + 1, new_node)
        parent.keys.insert(i, node.keys[t - 1])
        parent.values.insert(i, node.values[t - 1])
        new_node.keys = node.keys[t:(2 * t - 1)]
        new_node.values = node.values[t:(2 * t - 1)]
        node.keys = node.keys[:t - 1]
        node.values = node.values[:t - 1]
        if not node.leaf:
            new_node.children = node.children[t:(2 * t)]
            node.children = node.children[:t]


import openpyxl

def read_xlsx(file_path):
    wb = openpyxl.load_workbook(file_path)
    sheet = wb.active

    if sheet.max_row < 1:
        raise ValueError("Sheet Excel kosong atau tidak memiliki data.")
    
    # Membaca header dari baris pertama
    headers = [cell.value for cell in next(sheet.iter_rows(min_row=2, max_row=2))]
    
    data = []
    for row in sheet.iter_rows(min_row=2, values_only=True):
        record = {}
        for i, header in enumerate(headers):
            value = row[i] if i < len(row) else None
            if isinstance(value, str):
                value = value.strip()
            elif value is None:
                value = ""
            record[header] = value
        data.append(record)
    
    return data

def update_xlsx(schedule, file_path):
    from openpyxl import Workbook
    wb = Workbook()
    sheet = wb.active
    headers = ['Ruangan', 'Jam', 'Hari', 'Matkul', 'Kelas']
    sheet.append(headers)
    for record in schedule:
        row = [record.get(header, "") for header in headers]
        sheet.append(row)
    try:
        wb.save(file_path)
    except Exception as e:
        messagebox.showerror("Error", f"Error menulis ke file XLSX: {e}")

# Inisialisasi Global
file_path = "data.xlsx"
data = read_xlsx(file_path)
schedule = data  # Inisialisasi schedule dengan data yang dibaca
if data is None:
    raise ValueError("Data yang dibaca dari file XLSX adalah None.")

time_tree = BTreeKV(3) # tree disusun berdasarkan key gabungan dari hari dan jam 
kelas_tree = BTreeKV(3) # tree akan disusur berdasarkan key kelas spt 24E san sejenisnya untuk(pencarian jadwal)

def build_trees():
    for record in schedule:
        day = record['Hari']
        time = record['Jam']
        kelas = record['Kelas']
        if day is None or time is None or kelas is None:
            continue
        key_time = str(day).strip().lower() + "#" + str(time).strip()
        time_tree.insert(key_time, record)
        key_kelas = str(kelas).strip()
        kelas_tree.insert(key_kelas, record)

build_trees()

def print_root_tree(tree):
    root = tree.root
    print("Kunci di root:")
    for key, value in zip(root.keys, root.values):
        print(f"Kunci: {key}, Nilai: {value}")

def search_empty_room():
    selected_day = hari_combobox.get().strip().lower()
    output_text.delete("1.0", tk.END)
    found = False

    for record in schedule:
        if str(record["Hari"]).strip().lower() == selected_day and str(record["Matkul"]).strip().lower() == "kosong":
            if not found:
                output_text.insert(tk.END, "Ruang kosong:\n")
                found = True
            output_text.insert(tk.END, f" - {record['Ruangan']} | Jam: {record['Jam']}\n")
    
    if not found:
        output_text.insert(tk.END, "Tidak ada ruang kosong pada hari tersebut.\n")

def search_class_schedule():
    selected_class = kelas_combobox.get().strip()
    key = selected_class
    result = kelas_tree.search(kelas_tree.root, key)
    output_text_schedule.delete("1.0", tk.END)
    if not result:
        output_text_schedule.insert(tk.END, "Tidak ditemukan jadwal untuk kelas ini.\n")
    else:
        node, idx = result
        records = node.values[idx]
        output_text_schedule.insert(tk.END, f"Jadwal untuk kelas {selected_class}:\n")
        for rec in records:
            s = f"Hari: {rec['Hari']} | Jam: {rec['Jam']} | Ruangan: {rec['Ruangan']} | Matkul: {rec['Matkul']}\n"
            output_text_schedule.insert(tk.END, s)

def add_schedule():
    ruangan = entry_ruangan.get().strip()
    jam = entry_jam.get().strip()
    hari = entry_hari.get().strip().lower()
    matkul = entry_matkul.get().strip()
    kelas = entry_kelas.get().strip()

    if not (ruangan and jam and hari and matkul and kelas):
        messagebox.showerror("Error", "Semua field harus diisi!")
        return

    updated = False
    key_time = hari + "#" + jam

    for record in schedule:
        if record['Hari'].strip().lower() == hari and record['Jam'].strip() == jam:
            # Update matkul dan kelas
            record['Matkul'] = matkul
            record['Kelas'] = kelas
            updated = True
            break

    new_record = {
        "Ruangan": ruangan,
        "Jam": jam,
        "Hari": hari,
        "Matkul": matkul,
        "Kelas": kelas
    }

    if not updated:
        schedule.append(new_record)

    # Tambahkan (insert) ke tree (meskipun bisa duplikat, tapi tidak akan bermasalah jika hanya untuk baca)
    time_tree.insert(key_time, new_record)
    kelas_tree.insert(kelas, new_record)

    if updated:
        messagebox.showinfo("Sukses", "Jadwal berhasil diperbarui (Matkul & Kelas).")
    else:
        messagebox.showinfo("Sukses", "Jadwal berhasil ditambahkan.")

    # Reset form input
    entry_ruangan.delete(0, tk.END)
    entry_jam.delete(0, tk.END)
    entry_hari.delete(0, tk.END)
    entry_matkul.delete(0, tk.END)
    entry_kelas.delete(0, tk.END)


def save_to_xlsx():
    update_xlsx(schedule, file_path)
    messagebox.showinfo("Sukses", f"Data telah disimpan ke {file_path}")

# Pembuatan GUI menggunakan Tkinter
root = tk.Tk()
root.title("Sistem Jadwal - B-Tree GUI (XLSX)")

notebook = ttk.Notebook(root)

# Tab 1: Cari Ruang Kosong
tab1 = ttk.Frame(notebook)
notebook.add(tab1, text="Cari Ruang Kosong")

form_frame = tk.Frame(tab1)
form_frame.grid(row=0, column=0, padx=20, pady=10, sticky="w")

label_hari = tk.Label(form_frame, text="Hari:", anchor="w", width=12)
label_hari.grid(row=0, column=0, padx=5, pady=5, sticky="w")
hari_options = ["senin", "selasa", "rabu", "kamis", "jumat"]
hari_combobox = ttk.Combobox(form_frame, values=hari_options, state="readonly", width=30)
hari_combobox.grid(row=0, column=1, padx=5, pady=5)
hari_combobox.current(0)


button_search_room = tk.Button(tab1, text="Cari Ruang Kosong", command=search_empty_room)
button_search_room.grid(row=1, column=0, pady=(0, 10))

output_text = tk.Text(tab1, height=18, width=112)
output_text.grid(row=2, column=0, padx=20, pady=(0, 20))

tab2 = ttk.Frame(notebook)
notebook.add(tab2, text="Cari Jadwal Kelas")

form_frame2 = tk.Frame(tab2)
form_frame2.grid(row=0, column=0, padx=20, pady=10, sticky="w")

label_kelas = tk.Label(form_frame2, text="Kelas:", anchor="w", width=12)
label_kelas.grid(row=0, column=0, padx=5, pady=5, sticky="w")
kelas_options_list = [
    "24A", "24B", "24C", "24D", "24E", "24F",
    "23A", "23B", "23C", "23D", "23E", "23F",
    "23G", "PF-24C", "SD1-T24"
]
kelas_combobox = ttk.Combobox(form_frame2, values=kelas_options_list, state="readonly", width=30)
kelas_combobox.grid(row=0, column=1, padx=5, pady=5)
kelas_combobox.current(0)

button_search_class = tk.Button(tab2, text="Cari Jadwal Kelas", command=search_class_schedule)
button_search_class.grid(row=1, column=0, pady=(0, 10))

output_text_schedule = tk.Text(tab2, height=20, width=112)
output_text_schedule.grid(row=2, column=0, padx=20, pady=(0, 20))


# Tab 3: Update / Tambah Jadwal

tab3 = ttk.Frame(notebook)
notebook.add(tab3, text="Update Jadwal")

form_frame3 = tk.Frame(tab3)
form_frame3.grid(row=0, column=0, padx=20, pady=10, sticky="w")

label_ruangan = tk.Label(form_frame3, text="Ruangan:", width=12, anchor="w")
label_ruangan.grid(row=0, column=0, padx=5, pady=5, sticky="w")
entry_ruangan = tk.Entry(form_frame3, width=30)
entry_ruangan.grid(row=0, column=1, padx=5, pady=5)

label_jam = tk.Label(form_frame3, text="Jam:", width=12, anchor="w")
label_jam.grid(row=1, column=0, padx=5, pady=5, sticky="w")
entry_jam = tk.Entry(form_frame3, width=30)
entry_jam.grid(row=1, column=1, padx=5, pady=5)

label_hari = tk.Label(form_frame3, text="Hari:", width=12, anchor="w")
label_hari.grid(row=2, column=0, padx=5, pady=5, sticky="w")
entry_hari = tk.Entry(form_frame3, width=30)
entry_hari.grid(row=2, column=1, padx=5, pady=5)

label_matkul = tk.Label(form_frame3, text="Matkul:", width=12, anchor="w")
label_matkul.grid(row=3, column=0, padx=5, pady=5, sticky="w")
entry_matkul = tk.Entry(form_frame3, width=30)
entry_matkul.grid(row=3, column=1, padx=5, pady=5)

label_kelas = tk.Label(form_frame3, text="Kelas:", width=12, anchor="w")
label_kelas.grid(row=4, column=0, padx=5, pady=5, sticky="w")
entry_kelas = tk.Entry(form_frame3, width=30)
entry_kelas.grid(row=4, column=1, padx=5, pady=5)

button_add = tk.Button(tab3, text="Tambah Jadwal", command=add_schedule)
button_add.grid(row=1, column=0, pady=(0, 5))
button_save = tk.Button(tab3, text="Simpan ke XLSX", command=save_to_xlsx)
button_save.grid(row=2, column=0, pady=(0, 10))
notebook.pack(expand=1, fill="both")

# Menampilkan hasil root tree
print_root_tree(time_tree)
print_root_tree(kelas_tree)

root.geometry("950x450")  # Atur ukuran jendela, bisa disesuaikan
root.mainloop()
